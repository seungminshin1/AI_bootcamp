
ESP32 Temperature Logger to InfluxDB

<img width="403" alt="Screenshot 2024-10-29 at 11 36 54 AM" src="https://github.com/user-attachments/assets/ce73512d-9ac3-46e7-9553-cb72250b1f0a">

